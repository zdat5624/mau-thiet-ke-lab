public class AddStrategy implements OperationStrategy {
    @Override
    public double doOperation(double a, double b) {
        return a + b;
    }
}
