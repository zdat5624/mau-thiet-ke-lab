public interface OperationStrategy {
    double doOperation(double a, double b);
}
