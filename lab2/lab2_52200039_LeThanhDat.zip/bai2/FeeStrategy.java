public interface FeeStrategy {
    float calculateFee(float hours);
}
