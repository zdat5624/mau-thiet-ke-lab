public enum VehicleType {
    BICYCLE,
    MOTORBIKE,
    CAR
}
