public interface AbilityStrategy {
    void executeAbility(String targetName);
}
