public interface SortStrategy {
    void sort(int[] arr);
}